Packetizer
==========

.. automodule:: paramiko.packet
